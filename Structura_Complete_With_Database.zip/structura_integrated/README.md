# Structura — Building Risk Scanner (integrated project)

This package integrates the uploaded premium single-file HTML frontend with a FastAPI + SQLAlchemy REST API. The original dashboard, forms, questionnaire, report visuals, history table, safety pages, and rule-based scoring presentation are retained. A small connection indicator was added to show cloud/offline save state.

## Features

- Create/list/read/update/delete assessments: `/api/assessments`
- Assessment audit history: `/api/history` and `/api/assessments/{id}/history`
- Health check: `/api/health`
- SQLite by default; PostgreSQL via `DATABASE_URL`
- Stable frontend report IDs (`client_id`) make create retries idempotent.
- Frontend-first localStorage cache; attempts cloud save when online and queues local creates/deletes for retry when connectivity returns.
- PWA manifest, 192px/512px icons, and service worker. API requests are never cached.
- JSON export/import retained.

## Run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux/Android terminal: source .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

Open `http://127.0.0.1:8000/`. API docs are at `/docs`; health check is `/api/health`.

SQLite database `structura.db` is created in the current working directory. Set `DATABASE_URL` before starting the app to use PostgreSQL. For PostgreSQL, use a provider's connection URL and ensure the provider's SSL requirements are met; this project uses `psycopg[binary]` as its driver.

## Android-only workflow (no laptop)

1. Install a reputable Android Python environment that supports `pip` and a terminal (for example, Termux from its official source). Package support can vary by Android version.
2. Transfer/extract this ZIP in the phone's storage and open a terminal in the extracted project directory.
3. Install dependencies with `pip install -r backend/requirements.txt`.
4. Start the server using `uvicorn backend.main:app --host 0.0.0.0 --port 8000`.
5. In the same phone's browser, open `http://127.0.0.1:8000/`. This is a local development server, not an online deployment. PWA installation generally requires HTTPS (or localhost); local loopback can work in supported browsers.
6. To deploy publicly, use an Android browser to sign in to a Python-capable hosting provider, upload the project ZIP/repository, set the start command to `uvicorn backend.main:app --host 0.0.0.0 --port $PORT` (adapt if the host requires a different port variable), and configure `DATABASE_URL` with the provider's persistent PostgreSQL connection string. Choose a host that supports persistent Python web services and confirm its filesystem/database persistence policies.
7. Open the deployed HTTPS URL in Chrome on Android, use the browser menu, and choose **Install app** or **Add to Home screen** if offered.

No provider account or cloud deployment is configured by this source package; provider dashboards and free-tier limits change over time. Do not rely on SQLite on ephemeral hosting disks for long-term data persistence.

## Tests

Run from the project root:

```bash
pytest -q backend/tests
```

Tests cover health, create/read/update/delete, duplicate create retries, history, invalid risk score validation, and missing-record handling. Run them in the target deployment environment as well before public use.

## Security and limitations

- **No authentication or authorization is implemented.** Anyone who can reach the deployed API may be able to list, create, update, or delete all assessments. Do not publicly deploy with real personal information until authentication, per-user access control, rate limiting, and an appropriate privacy policy are added.
- CORS is not required for the bundled same-origin frontend. If hosting the frontend separately later, configure a strict CORS allowlist.
- The assessment score is a preliminary educational screening indicator only—not a structural engineering opinion, official hazard prediction, or guarantee of safety.
- Photo evidence remains session-only in the existing frontend and is not uploaded or attached to reports. Emergency kit checklist remains browser-local.
- The app synchronizes up to the API's configured page limit (200 records in the current frontend sync routine); if you expect more records, implement pagination before bulk sync.
- Browser storage can be cleared by the user or browser. Export JSON backups regularly, especially before first cloud sync.

## API payload mapping

The frontend's complete report is saved in the API `report` JSON field. Building name/location/type/floors, answers, maximum risk score, overall indicator, recommendations, and timestamps are also stored in dedicated columns/fields. A server-side history snapshot is recorded for create/update/delete operations.
