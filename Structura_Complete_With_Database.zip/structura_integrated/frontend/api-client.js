/*
 * Structura API helper. Add this script to your existing page without replacing its UI:
 * <script src="/assets/api-client.js" defer></script>
 *
 * This helper does not assume your form's field names. Map your current form's data to
 * the object accepted by saveAssessment() from your existing submit/save handler.
 */
(() => {
  const API = "/api";
  const LOCAL_KEY = "structura_assessments_offline_v1";

  function readLocal() {
    try { return JSON.parse(localStorage.getItem(LOCAL_KEY) || "[]"); }
    catch { return []; }
  }
  function writeLocal(rows) {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(rows));
  }
  function stableClientId(record) {
    if (record.client_id) return record.client_id;
    if (record.id && typeof record.id === "string") return record.id;
    if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
    return "structura-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  }
  async function request(path, options = {}) {
    const response = await fetch(API + path, {
      ...options,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) }
    });
    if (!response.ok) {
      let detail = `Request failed (${response.status})`;
      try { detail = (await response.json()).detail || detail; } catch {}
      throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
    }
    return response.status === 204 ? null : response.json();
  }

  async function saveAssessment(data) {
    const record = { ...data, client_id: stableClientId(data) };
    // Always stage locally first, so a temporary outage doesn't discard user work.
    const local = readLocal();
    const index = local.findIndex(x => x.client_id === record.client_id);
    if (index >= 0) local[index] = { ...local[index], ...record, sync_status: "pending" };
    else local.push({ ...record, sync_status: "pending" });
    writeLocal(local);

    try {
      let saved;
      if (record.id && Number.isInteger(Number(record.id))) {
        saved = await request(`/assessments/${Number(record.id)}`, {
          method: "PATCH", body: JSON.stringify(record)
        });
      } else {
        saved = await request("/assessments", { method: "POST", body: JSON.stringify(record) });
      }
      const current = readLocal();
      const i = current.findIndex(x => x.client_id === record.client_id);
      const synced = { ...saved, sync_status: "synced" };
      if (i >= 0) current[i] = synced; else current.push(synced);
      writeLocal(current);
      return { record: saved, source: "server" };
    } catch (error) {
      return { record, source: "local", warning: error.message };
    }
  }

  async function listAssessments() {
    try {
      const rows = await request("/assessments");
      // Server is authoritative for synced records; pending offline records are retained.
      const pending = readLocal().filter(x => x.sync_status === "pending");
      const byId = new Map(rows.map(x => [x.client_id, x]));
      for (const x of pending) if (!byId.has(x.client_id)) byId.set(x.client_id, x);
      return { records: [...byId.values()], source: "server" };
    } catch {
      return { records: readLocal(), source: "local" };
    }
  }

  async function getAssessment(id) {
    try { return { record: await request(`/assessments/${id}`), source: "server" }; }
    catch (error) {
      const found = readLocal().find(x => String(x.id) === String(id) || x.client_id === id);
      if (found) return { record: found, source: "local", warning: error.message };
      throw error;
    }
  }

  async function updateAssessment(id, patch) {
    try {
      const saved = await request(`/assessments/${id}`, { method: "PATCH", body: JSON.stringify(patch) });
      const rows = readLocal().map(x => String(x.id) === String(id) ? { ...saved, sync_status: "synced" } : x);
      writeLocal(rows);
      return { record: saved, source: "server" };
    } catch (error) {
      const rows = readLocal();
      const i = rows.findIndex(x => String(x.id) === String(id) || x.client_id === id);
      if (i < 0) throw error;
      rows[i] = { ...rows[i], ...patch, sync_status: "pending" };
      writeLocal(rows);
      return { record: rows[i], source: "local", warning: error.message };
    }
  }

  async function deleteAssessment(id) {
    // Do not silently delete a server record when disconnected: retain it and report failure.
    await request(`/assessments/${id}`, { method: "DELETE" });
    writeLocal(readLocal().filter(x => String(x.id) !== String(id) && x.client_id !== id));
  }

  async function history(id) {
    return request(`/assessments/${id}/history`);
  }

  async function syncPending() {
    const pending = readLocal().filter(x => x.sync_status === "pending");
    const results = [];
    for (const row of pending) {
      try {
        const payload = { ...row };
        delete payload.id; delete payload.sync_status; delete payload.created_at; delete payload.updated_at;
        const saved = await request("/assessments", { method: "POST", body: JSON.stringify(payload) });
        const rows = readLocal();
        const i = rows.findIndex(x => x.client_id === row.client_id);
        if (i >= 0) rows[i] = { ...saved, sync_status: "synced" };
        writeLocal(rows);
        results.push({ client_id: row.client_id, ok: true });
      } catch (e) {
        results.push({ client_id: row.client_id, ok: false, error: e.message });
      }
    }
    return results;
  }

  window.StructuraAPI = { saveAssessment, listAssessments, getAssessment, updateAssessment, deleteAssessment, history, syncPending };
})();
