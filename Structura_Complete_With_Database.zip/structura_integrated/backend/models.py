from datetime import datetime, timezone
from sqlalchemy import Column, DateTime, Float, Integer, String, Text, JSON, ForeignKey, Index
from sqlalchemy.orm import relationship
from .database import Base

def utcnow():
    return datetime.now(timezone.utc)

class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(String(64), unique=True, index=True, nullable=False)
    title = Column(String(200), nullable=False, default="Building assessment")
    building_name = Column(String(200), nullable=True)
    address = Column(String(500), nullable=True)
    building_type = Column(String(100), nullable=True)
    year_built = Column(Integer, nullable=True)
    floors = Column(Integer, nullable=True)
    answers = Column(JSON, nullable=False, default=dict)
    risk_score = Column(Float, nullable=True)
    risk_level = Column(String(40), nullable=True)
    recommendations = Column(JSON, nullable=False, default=list)
    report = Column(JSON, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    history = relationship("AssessmentHistory", back_populates="assessment",
                           cascade="all, delete-orphan", order_by="AssessmentHistory.changed_at")

class AssessmentHistory(Base):
    __tablename__ = "assessment_history"
    id = Column(Integer, primary_key=True, index=True)
    assessment_id = Column(Integer, ForeignKey("assessments.id", ondelete="CASCADE"), nullable=True, index=True)
    client_id = Column(String(64), nullable=False, index=True)
    action = Column(String(20), nullable=False)
    snapshot = Column(JSON, nullable=False)
    changed_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    assessment = relationship("Assessment", back_populates="history")

Index("ix_history_client_changed", AssessmentHistory.client_id, AssessmentHistory.changed_at)
