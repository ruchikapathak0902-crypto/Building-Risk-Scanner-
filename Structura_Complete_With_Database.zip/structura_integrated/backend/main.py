import os
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, Depends, HTTPException, Query, Request, status
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from .database import Base, engine, get_db
from .models import Assessment, AssessmentHistory
from .schemas import AssessmentCreate, AssessmentUpdate, AssessmentOut, HistoryOut

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Structura — Building Risk Scanner API",
    description="Assessment storage API. Risk results are preliminary screening indicators, not certified engineering assessments.",
    version="1.0.0",
)

def utcnow():
    return datetime.now(timezone.utc)

def snapshot(row: Assessment) -> dict[str, Any]:
    return {
        "id": row.id, "client_id": row.client_id, "title": row.title,
        "building_name": row.building_name, "address": row.address,
        "building_type": row.building_type, "year_built": row.year_built,
        "floors": row.floors, "answers": row.answers, "risk_score": row.risk_score,
        "risk_level": row.risk_level, "recommendations": row.recommendations,
        "report": row.report, "notes": row.notes,
        "created_at": row.created_at.isoformat() if row.created_at else None,
        "updated_at": row.updated_at.isoformat() if row.updated_at else None,
    }

def add_history(db: Session, row: Assessment, action: str):
    db.add(AssessmentHistory(
        assessment_id=row.id, client_id=row.client_id,
        action=action, snapshot=snapshot(row), changed_at=utcnow()
    ))

@app.get("/api/health")
def health():
    try:
        with engine.connect() as conn:
            conn.exec_driver_sql("SELECT 1")
        return {"status": "ok", "database": "connected", "timestamp": utcnow().isoformat()}
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail="Database unavailable")

@app.post("/api/assessments", response_model=AssessmentOut, status_code=status.HTTP_201_CREATED)
def create_assessment(payload: AssessmentCreate, db: Session = Depends(get_db)):
    existing = db.query(Assessment).filter(Assessment.client_id == payload.client_id).first()
    if existing:
        # Idempotent sync retry: return the existing record rather than creating a duplicate.
        return existing
    row = Assessment(**payload.model_dump())
    db.add(row)
    try:
        db.flush()
        add_history(db, row, "created")
        db.commit()
        db.refresh(row)
        return row
    except IntegrityError:
        db.rollback()
        existing = db.query(Assessment).filter(Assessment.client_id == payload.client_id).first()
        if existing:
            return existing
        raise HTTPException(status_code=409, detail="Assessment conflicts with an existing record")
    except SQLAlchemyError:
        db.rollback()
        raise HTTPException(status_code=500, detail="Could not save assessment")

@app.get("/api/assessments", response_model=list[AssessmentOut])
def list_assessments(
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    return db.query(Assessment).order_by(Assessment.updated_at.desc()).offset(skip).limit(limit).all()

@app.get("/api/assessments/{assessment_id}", response_model=AssessmentOut)
def get_assessment(assessment_id: int, db: Session = Depends(get_db)):
    row = db.get(Assessment, assessment_id)
    if not row:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return row

@app.patch("/api/assessments/{assessment_id}", response_model=AssessmentOut)
def update_assessment(assessment_id: int, payload: AssessmentUpdate, db: Session = Depends(get_db)):
    row = db.get(Assessment, assessment_id)
    if not row:
        raise HTTPException(status_code=404, detail="Assessment not found")
    changes = payload.model_dump(exclude_unset=True)
    if not changes:
        return row
    for key, value in changes.items():
        setattr(row, key, value)
    row.updated_at = utcnow()
    try:
        db.flush()
        add_history(db, row, "updated")
        db.commit()
        db.refresh(row)
        return row
    except SQLAlchemyError:
        db.rollback()
        raise HTTPException(status_code=500, detail="Could not update assessment")

@app.delete("/api/assessments/{assessment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_assessment(assessment_id: int, db: Session = Depends(get_db)):
    row = db.get(Assessment, assessment_id)
    if not row:
        raise HTTPException(status_code=404, detail="Assessment not found")
    # Keep a final tombstone snapshot so deletion is auditable even after the row is gone.
    db.add(AssessmentHistory(
        assessment_id=None, client_id=row.client_id, action="deleted",
        snapshot=snapshot(row), changed_at=utcnow()
    ))
    db.delete(row)
    try:
        db.commit()
    except SQLAlchemyError:
        db.rollback()
        raise HTTPException(status_code=500, detail="Could not delete assessment")
    return None

@app.get("/api/assessments/{assessment_id}/history", response_model=list[HistoryOut])
def assessment_history(assessment_id: int, db: Session = Depends(get_db)):
    row = db.get(Assessment, assessment_id)
    if not row:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return db.query(AssessmentHistory).filter(
        AssessmentHistory.client_id == row.client_id
    ).order_by(AssessmentHistory.changed_at.desc()).all()

@app.get("/api/history", response_model=list[HistoryOut])
def all_history(
    client_id: str | None = None,
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    q = db.query(AssessmentHistory)
    if client_id:
        q = q.filter(AssessmentHistory.client_id == client_id)
    return q.order_by(AssessmentHistory.changed_at.desc()).offset(skip).limit(limit).all()

# Serve existing frontend files from ../frontend when present. API routes remain under /api.
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
if FRONTEND_DIR.exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIR)), name="frontend-assets")

    @app.get("/service-worker.js", include_in_schema=False)
    def service_worker():
        worker = FRONTEND_DIR / "service-worker.js"
        if not worker.exists():
            raise HTTPException(status_code=404, detail="service-worker.js not found")
        return FileResponse(worker, media_type="application/javascript")

    @app.get("/", include_in_schema=False)
    def frontend_index():
        index = FRONTEND_DIR / "index.html"
        if not index.exists():
            raise HTTPException(status_code=404, detail="frontend/index.html not found")
        return FileResponse(index)
