import os
import uuid
from fastapi.testclient import TestClient

# Tests use a dedicated SQLite file, never a configured production database.
os.environ["DATABASE_URL"] = "sqlite:///./test_structura.db"
from backend.main import app
from backend.database import Base, engine

client = TestClient(app)

def setup_function():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

def sample_payload():
    return {
        "client_id": str(uuid.uuid4()),
        "title": "Apartment screening",
        "building_name": "Demo House",
        "building_type": "residential",
        "year_built": 2005,
        "floors": 3,
        "answers": {"cracks": "minor", "water_damage": False},
        "risk_score": 24.5,
        "risk_level": "low",
        "recommendations": ["Monitor visible cracks"],
        "report": {"summary": "Preliminary screening only"}
    }

def test_health():
    assert client.get("/api/health").status_code == 200

def test_create_read_update_delete_and_history():
    payload = sample_payload()
    created = client.post("/api/assessments", json=payload)
    assert created.status_code == 201
    item = created.json()
    assert item["answers"]["cracks"] == "minor"

    # Idempotent retry must not create a second record.
    retry = client.post("/api/assessments", json=payload)
    assert retry.status_code == 201
    assert retry.json()["id"] == item["id"]
    assert len(client.get("/api/assessments").json()) == 1

    assert client.get(f"/api/assessments/{item['id']}").status_code == 200
    updated = client.patch(f"/api/assessments/{item['id']}", json={"risk_score": 42})
    assert updated.status_code == 200
    assert updated.json()["risk_score"] == 42

    history = client.get(f"/api/assessments/{item['id']}/history")
    assert history.status_code == 200
    assert {x["action"] for x in history.json()} >= {"created", "updated"}

    deleted = client.delete(f"/api/assessments/{item['id']}")
    assert deleted.status_code == 204
    assert client.get(f"/api/assessments/{item['id']}").status_code == 404
    assert any(x["action"] == "deleted" for x in client.get("/api/history").json())

def test_validation_and_not_found():
    bad = sample_payload()
    bad["risk_score"] = 150
    assert client.post("/api/assessments", json=bad).status_code == 422
    assert client.get("/api/assessments/99999").status_code == 404
