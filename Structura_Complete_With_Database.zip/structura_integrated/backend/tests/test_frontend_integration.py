from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HTML = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
SW = (ROOT / "frontend" / "service-worker.js").read_text(encoding="utf-8")

def test_frontend_contains_api_sync_and_existing_pages():
    assert 'fetch(API_BASE+path' in HTML
    assert 'syncPending()' in HTML
    assert 'id="page-dashboard"' in HTML
    assert 'id="page-survey"' in HTML
    assert 'id="page-report"' in HTML
    assert 'id="page-reports"' in HTML

def test_service_worker_does_not_cache_api_requests():
    assert 'url.pathname.startsWith("/api/")' in SW
    assert 'request.method !== "GET"' in SW

def test_pwa_manifest_and_icons_exist():
    assert (ROOT / "frontend" / "manifest.webmanifest").exists()
    assert (ROOT / "frontend" / "icons" / "icon-192.png").exists()
    assert (ROOT / "frontend" / "icons" / "icon-512.png").exists()


def test_app_serves_frontend_and_pwa_assets():
    from fastapi.testclient import TestClient
    from backend.main import app
    client = TestClient(app)
    home = client.get("/")
    assert home.status_code == 200
    assert "Structura | Building Risk Scanner" in home.text
    manifest = client.get("/assets/manifest.webmanifest")
    assert manifest.status_code == 200
    assert manifest.json()["name"].startswith("Structura")
    icon = client.get("/assets/icons/icon-192.png")
    assert icon.status_code == 200
    assert icon.headers["content-type"].startswith("image/png")
