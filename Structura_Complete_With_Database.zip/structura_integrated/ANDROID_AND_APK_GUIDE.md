# Structura on Android: run locally, install as PWA, and APK notes

## What this ZIP contains

This is the integrated source project: existing HTML frontend, FastAPI backend, SQLAlchemy models, SQLite-by-default database configuration, API routes, tests, PWA manifest, service worker, and icons.

## Run locally on Android (Termux)

1. Extract this ZIP into a folder you can access from Termux.
2. In Termux, `cd` into the extracted `structura_integrated` project root (the folder containing `backend/` and `frontend/`).
3. Install packages using the Termux package manager first if needed, then run:

   ```sh
   pkg update
   pkg install python
   python -m pip install -r backend/requirements.txt
   ```

   Do not run `pip install --upgrade pip` in Termux. If `pydantic-core` fails to build on your Android/Python version, stop and use a compatible Python environment or deploy the backend to a Python-capable host; do not assume the install succeeded.

4. Start the app from the project root:

   ```sh
   uvicorn backend.main:app --host 127.0.0.1 --port 8000
   ```

5. On the same phone, open `http://127.0.0.1:8000/` in Chrome. API health: `http://127.0.0.1:8000/api/health`. API docs: `http://127.0.0.1:8000/docs`.

The SQLite file `structura.db` is created by the app in its current working directory when the database initializes. Back it up; deleting it deletes the local server's saved records.

## Install on the Android home screen

For a local server, open the app URL in Chrome and use the browser menu to choose **Install app** or **Add to Home screen** if available. Browser/PWA installation support can vary. This creates a home-screen web app, not a standalone APK, and the local backend must still be running in Termux.

## About making a standalone APK

A genuine APK is not produced by this source ZIP alone. A WebView wrapper can package the interface, but it cannot magically run this Python/FastAPI server and SQLite database inside Android. A standalone APK with the backend bundled needs additional Android packaging/build work and platform testing. The practical first option is to host this FastAPI app with a persistent PostgreSQL database, then wrap/install the HTTPS PWA. Do not publish a public service before adding authentication and access control.

## Security and limitations

- This app currently has no authentication/authorization; do not expose it publicly with real assessment data until that is added.
- Risk scores are preliminary screening indicators, not certified structural-engineering assessments.
- Android Termux package compatibility varies; this guide does not claim the dependencies install on every device.
